package com.hnpalert.app

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HNPNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val targetPackage = prefs.getString(Prefs.TARGET_PACKAGE, "")?.trim() ?: ""
        val keyword = prefs.getString(Prefs.KEYWORD, "")?.trim()?.lowercase() ?: ""

        // Ignore our own notifications / the alarm we raise ourselves
        if (sbn.packageName == packageName) return

        // If a target package is set, only react to notifications from that app
        if (targetPackage.isNotEmpty() && sbn.packageName != targetPackage) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val combined = (title + " " + text).lowercase()

        // If a keyword is set, require it to appear in the notification content
        if (keyword.isNotEmpty() && !combined.contains(keyword)) return

        // If neither target package nor keyword is set, react to nothing (avoid false alarms)
        if (targetPackage.isEmpty() && keyword.isEmpty()) return

        val alarmIntent = Intent(this, AlarmActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("title", if (title.isNotEmpty()) title else "NEW HNP JOB")
            putExtra("text", text)
        }
        startActivity(alarmIntent)
    }
}
