package com.hnpalert.app

import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class InstalledAppsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val listView = ListView(this)
        setContentView(listView)

        val pm = packageManager
        val apps: List<ApplicationInfo> = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val labels = apps.map { "${pm.getApplicationLabel(it)}\n${it.packageName}" }

        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        listView.setOnItemClickListener { _, _, position, _ ->
            val chosen = apps[position]
            getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
                .putString(Prefs.TARGET_PACKAGE, chosen.packageName)
                .apply()
            Toast.makeText(
                this,
                "Selected: ${pm.getApplicationLabel(chosen)}",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }
}
