package com.hnpalert.app

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)

        val statusText = findViewById<android.widget.TextView>(R.id.statusText)
        val packageInput = findViewById<android.widget.EditText>(R.id.packageInput)
        val keywordInput = findViewById<android.widget.EditText>(R.id.keywordInput)
        val saveBtn = findViewById<android.widget.Button>(R.id.saveBtn)
        val grantBtn = findViewById<android.widget.Button>(R.id.grantBtn)
        val testBtn = findViewById<android.widget.Button>(R.id.testBtn)
        val listAppsBtn = findViewById<android.widget.Button>(R.id.listAppsBtn)

        packageInput.setText(prefs.getString(Prefs.TARGET_PACKAGE, ""))
        keywordInput.setText(prefs.getString(Prefs.KEYWORD, "job"))

        saveBtn.setOnClickListener {
            prefs.edit()
                .putString(Prefs.TARGET_PACKAGE, packageInput.text.toString().trim())
                .putString(Prefs.KEYWORD, keywordInput.text.toString().trim())
                .apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        grantBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        testBtn.setOnClickListener {
            startActivity(Intent(this, AlarmActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("title", "TEST HNP JOB")
            })
        }

        listAppsBtn.setOnClickListener {
            startActivity(Intent(this, InstalledAppsActivity::class.java))
        }

        statusText.text = if (isListenerEnabled()) {
            "✅ Notification access ON"
        } else {
            "⚠️ Notification access OFF — tap Grant Access below"
        }
    }

    override fun onResume() {
        super.onResume()
        recreate()
    }

    private fun isListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabled != null && enabled.contains(packageName)
    }
}

object Prefs {
    const val NAME = "hnp_alert_prefs"
    const val TARGET_PACKAGE = "target_package"
    const val KEYWORD = "keyword"
}
